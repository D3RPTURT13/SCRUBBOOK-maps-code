import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
/**
 * This program demonstrates how a map (dictionary) data structure is
 * implemented in Java.
 */
public class Scrubbook {

    public static void main(String[] args) {

	// Define the map
	Map<String, Double> SCRUBBOOK = new HashMap<String, Double>();

	// Put some data into the map
	System.out.println("Welcumz to the SCRUBBOOK SCRUB!, who YOU BE?");
	Scanner scnr = new Scanner(System.in);
	String n1 = scnr.next();
	System.out.println("NO WELCOME, " + n1 + "! WHAT DOES SCRUB WANT DO WITH THE SCRUBBOOOOOK!?");
	String m1 = scnr.next();
	if (m1.equals("check")) {
		System.out.println("HERE BE THE SCRUBZ YOU IS LOOKING FOR!!!!:");
		SCRUBBOOK.put("xXN00BDESTROYERXx", 92.5);
		SCRUBBOOK.put("Help me", 19.2);
		SCRUBBOOK.put("D00MGU7", 59.3);
		SCRUBBOOK.put("MaK3myD4Y", 79.0);
		SCRUBBOOK.put("B4c0nlov3r12345", 69.2);
		SCRUBBOOK.forEach( (name, scrublevel) -> System.out.println("there is a scrub known as " + name) );
	} else if (m1.equals("search")){
		System.out.println("ALRIGHT, " + n1 + ", WHAT SCRUB ARE YOU LOOKING FOR!?");
		String s1 = scnr.next();
		if (s1.equals("xXN00BDESTROYERXx")) {
			SCRUBBOOK.put("xXN00BDESTROYERXx", 92.5);
			SCRUBBOOK.forEach( (name, scrublevel) -> System.out.println("the scrub known as " + name + "'s SCRUBLEVEL is " + scrublevel) );
		}else if (s1.equals("Help me")){
			SCRUBBOOK.put("Help me", 19.2);
			SCRUBBOOK.forEach( (name, scrublevel) -> System.out.println("the scrub known as " + name + "'s SCRUBLEVEL is " + scrublevel) );
		}else if (s1.equals("D00MGU7")){
			SCRUBBOOK.put("D00MGU7", 59.5);
			SCRUBBOOK.forEach( (name, scrublevel) -> System.out.println("the scrub known as " + name + "'s SCRUBLEVEL is " + scrublevel) );
		}else if (s1.equals("MaK3myD4Y")){
			SCRUBBOOK.put("MaK3myD4Y", 79.0);
			SCRUBBOOK.forEach( (name, scrublevel) -> System.out.println("the scrub known as " + name + "'s SCRUBLEVEL is " + scrublevel) );
		}else if (s1.equals("B4c0nlov3r12345")){
			SCRUBBOOK.put("B4c0nlov3r12345", 69.2);
			SCRUBBOOK.forEach( (name, scrublevel) -> System.out.println("the scrub known as " + name + "'s SCRUBLEVEL is " + scrublevel) );
		}else{
			System.out.println("THAT PERSON OR STATEMENT ISN'T RIGHT!!!! MAKE SURE YOU KNOW WHAT YOU "
					+ "WANT BEFORE LOOKING FOR A SCRUB, YOU SCRUB! PICK THAT GREEN RESTART NOW!");
		}
	} else {
		System.out.println("THAT PERSON OR STATEMENT ISN'T RIGHT!!!! MAKE SURE YOU KNOW WHAT YOU "
				+ "WANT BEFORE LOOKING FOR A SCRUB, YOU SCRUB!");
	}
	
    }
}
